import cv2
import os

IMAGES_DIR = "./tilted_50_regular/train/images"
LABELS_DIR = "./tilted_50_regular/train/labels"
OUTPUT_DIR = "gt_crops_TILTED_nonobb"
PADDING    = 2

os.makedirs(OUTPUT_DIR, exist_ok=True)

image_filenames = sorted(
    f for f in os.listdir(IMAGES_DIR)
    if f.lower().endswith((".jpg"))
)

print(f"Processing {len(image_filenames)} images...")

counter = 0

for image_filename in image_filenames:
    image_path = os.path.join(IMAGES_DIR, image_filename)
    base_name, _ = os.path.splitext(image_filename)
    label_path = os.path.join(LABELS_DIR, f"{base_name}.txt")

    if not os.path.exists(label_path):
        print(f"Skipping {image_filename} - label not found")
        continue

    frame = cv2.imread(image_path)
    if frame is None:
        print(f"Skipping {image_filename} — could not read")
        continue

    h_img, w_img = frame.shape[:2]

    with open(label_path, "r") as f:
        lines = f.readlines()

    for line in lines:
        parts = line.strip().split()
        if len(parts) != 5:
            continue

        class_id = int(parts[0])
        cx, cy, bw, bh = [float(p) for p in parts[1:]]

        x1 = max(0, int((cx - bw / 2) * w_img) - PADDING)
        y1 = max(0, int((cy - bh / 2) * h_img) - PADDING)
        x2 = min(w_img, int((cx + bw / 2) * w_img) + PADDING)
        y2 = min(h_img, int((cy + bh / 2) * h_img) + PADDING)

        cropped = frame[y1:y2, x1:x2]
        if cropped.size > 0:
            filename = os.path.join(OUTPUT_DIR, f"{counter:04d}.jpg")
            cv2.imwrite(filename, cropped)
            print(f"Saved: {filename} (class {class_id})")
            counter += 1

print(f"\nDone. Total crops saved: {counter}")