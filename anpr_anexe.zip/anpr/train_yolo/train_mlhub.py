import torch
import os
from ultralytics import YOLO


def main():
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")
    if device == 'cuda':
        print(torch.cuda.get_device_name(0))

    model = YOLO('yolo11n-obb.pt').to(device)

    # Create the runs directory first if it doesn't exist
    os.makedirs('runs', exist_ok=True)

    model.train(
        data="datasets/CarplateDetection-24/data.yaml",
        epochs=200,
        batch=32,
        imgsz=640,

        hsv_h=0.015,
        hsv_s=0.5,
        hsv_v=0.3,

        degrees=3,
        translate=0.08,
        scale=0.4,
        shear=1.5,
        perspective=0.0003,

        fliplr=0.5,
        flipud=0.0,

        mosaic=0.5,
        close_mosaic=10,
        mixup=0.05,

        amp=True,
        patience=15,

        lr0=0.005,
        cos_lr=False,

        project="runs",
        name="train_results_v24_yolov11n-obb_cosFalse_lr005_b32_noroboaugm",
    )


if __name__ == "__main__":
    main()